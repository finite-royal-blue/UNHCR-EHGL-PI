YUI's change history is available in two formats:

* Per-Release on the Wiki:
  * [Current Release](https://github.com/yui/yui3/wiki#current-release)
  * [Past Releases](https://github.com/yui/yui3/wiki#past-releases)
* Per-Component in each component's `HISTORY.md` 
  (e.g. [`/src/app/HISTORY.md`](https://github.com/yui/yui3/blob/master/src/app/HISTORY.md)).

