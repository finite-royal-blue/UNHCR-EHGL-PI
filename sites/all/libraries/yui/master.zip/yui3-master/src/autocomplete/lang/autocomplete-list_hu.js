{
    // ARIA live region notifications.
    item_selected  : "{item} kiv\u00e1lasztva.",
    items_available: "Javaslatok \u00e1llnak rendelkez\u00e9sre. Haszn\u00e1lja a fel \u00e9s le nyilakat a v\u00e1laszt\u00e1shoz."
}
