{
    // ARIA live region notifications.
    item_selected  : "{item} selezionato.",
    items_available: "Sono disponibili suggerimenti. Usa la freccia su e gi\u00F9 per selezionare."
}
