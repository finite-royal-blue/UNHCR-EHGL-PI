Button Change History
====================

@VERSION@
------

* No changes.

3.18.1
------

* No changes.

3.18.0
------

* No changes.

3.17.2
------

* No changes.

3.17.1
------

* No changes.

3.17.0
------

* No changes.

3.16.0
------

* No changes.

3.15.0
------

* No changes.

3.14.1
------

* No changes.

3.14.0
------

* Fixed `disabledChange` listener to correctly disable or enable
  buttons. ([#1374][]: @drjayvee)

[#1374]: https://github.com/yui/yui3/pull/1374

3.13.0
------

* Added a `labelHTML` attribute to `Y.ButtonCore` for nested HTML label support
* Due to a fix in `Y.Widget` (#1125), `Y.Button` now correctly retains all node attributes upon render

3.12.0
------

* `ButtonGroup.disable()` will disable each child button (or input, see `getButtons()`)

3.11.0
------

* No changes.

3.10.3
------

* No changes.

3.10.2
------

* No changes.

3.10.1
------

* No changes.

3.10.0
------

* No changes.

3.9.1
-----

* No changes.

3.9.0
-----

 * Fixed issue where disabled button widgets are still clickable (#2532775)

3.8.1
-----

* Documentation updates.
* Linting cleanup.

3.8.0
-----

* No changes.

3.7.3
-----

* No changes.

3.7.2
-----

* No changes.

3.7.1
-----

* No changes.

3.7.0
-----

* No changes.

3.6.0
-----
  * #2532458 - ButtonGroup properly handles nested labels.

3.5.1
-----

  * No changes.

3.5.0
-----

  * Initial Release
