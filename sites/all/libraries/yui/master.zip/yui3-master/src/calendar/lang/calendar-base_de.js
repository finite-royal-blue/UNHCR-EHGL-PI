{
    very_short_weekdays : ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"],
    first_weekday : 1,
    weekends : [0,6]
}
