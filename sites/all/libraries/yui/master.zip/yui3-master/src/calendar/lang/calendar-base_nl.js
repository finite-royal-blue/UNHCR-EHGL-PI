{
    very_short_weekdays : ["zo", "ma", "di", "woe", "do", "vr", "za"],
    first_weekday : 1,
    weekends : [0,6]
}
