{
    very_short_weekdays : ["V", "H", "K", "Sze", "Cs", "P", "Szo"],
    first_weekday : 1,
    weekends : [0,6]
}
