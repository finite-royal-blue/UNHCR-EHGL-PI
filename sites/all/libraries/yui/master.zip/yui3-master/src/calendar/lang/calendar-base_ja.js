{
    very_short_weekdays : ["\u65E5", "\u6708", "\u706B", "\u6C34", "\u6728", "\u91D1", "\u571F"],
    first_weekday : 0,
    weekends : [0,6]
}
