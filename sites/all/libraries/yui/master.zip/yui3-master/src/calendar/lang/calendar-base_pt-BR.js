{
    very_short_weekdays : ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"],
    first_weekday : 0,
    weekends : [0,6]
}
