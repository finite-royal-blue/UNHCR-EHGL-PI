{
    very_short_weekdays : ["Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa"],
    first_weekday : 1,
    weekends : [0,6]
}
