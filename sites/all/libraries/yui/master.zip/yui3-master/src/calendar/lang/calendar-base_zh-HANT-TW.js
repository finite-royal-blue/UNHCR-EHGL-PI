{
    very_short_weekdays : ["\u65E5", "\u4e00", "\u4e8c", "\u4e09", "\u56db", "\u4e94", "\u516d"],
    first_weekday : 0,
    weekends : [0,6]
}
