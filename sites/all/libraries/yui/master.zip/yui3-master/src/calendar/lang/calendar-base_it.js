{
    very_short_weekdays : ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa"],
    first_weekday : 1,
    weekends : [0,6]
}
