{
    very_short_weekdays : ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"],
    first_weekday : 1,
    weekends : [0,6]
}
