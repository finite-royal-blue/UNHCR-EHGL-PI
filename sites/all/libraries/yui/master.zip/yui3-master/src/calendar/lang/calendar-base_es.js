{
    very_short_weekdays : ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa"],
    first_weekday : 1,
    weekends : [0,6]
}
