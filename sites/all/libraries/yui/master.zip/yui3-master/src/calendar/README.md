Calendar
========

Calendar is a visual and interactive representation of a date
range, in one or more month grids. Calendar allows custom date
rendering based on specific rules, date selection, and date
range navigation.

The modules in Calendar include CalendarBase, Calendar, and
CalendarNavigator plugin.
