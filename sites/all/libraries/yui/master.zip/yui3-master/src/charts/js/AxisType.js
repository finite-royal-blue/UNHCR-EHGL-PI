Y.AxisType = Y.Base.create("baseAxis", Y.Axis, [], {});
