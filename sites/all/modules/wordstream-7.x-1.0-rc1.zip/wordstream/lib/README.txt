; $Id $

In this directory you need to put the wordstream class. Simply copy and paste the code from:

https://api.wordstream.com/doc/sample_code?doc=wordstream_api.php&label=WordStream%20API%20Sample%20Code

into a file named "class.wordstream.inc" and place it in this directory.

If you have the Libraries module enabled you can place the file in the libraries directory, e.g. sites/all/libraries/wordstream/class.wordstream.inc
